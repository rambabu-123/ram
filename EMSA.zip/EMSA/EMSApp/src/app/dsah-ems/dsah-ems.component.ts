import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ApiService } from '../shared/api.service';
import { EmpData } from '../shared/EmpData.model';

@Component({
  selector: 'app-dsah-ems',
  templateUrl: './dsah-ems.component.html',
  styleUrls: ['./dsah-ems.component.css']
})
export class DsahEmsComponent implements OnInit {
formValue!:FormGroup
empobj:EmpData=new EmpData
empAlldata!:EmpData[];
  constructor(private formBuilder:FormBuilder,private api:ApiService) {
   }
  ngOnInit(): void {
    this.formValue=this.formBuilder.group({
     name:[' '],
     email:[' '],
     mobile:[' '],
     address:[' '],
     salary:[' ']
    })
    this.getAllData()
  }
  addEmp()
  {
    this.empobj.name=this.formValue.value.name;
    this.empobj.email=this.formValue.value.email;
    this.empobj.mobile=this.formValue.value.mobile;
    this.empobj.address=this.formValue.value.address;
    this.empobj.salary=this.formValue.value.salary;
    //subscribe to api services
    this.api.postEmp(this.empobj).subscribe(res=>
      
      {
        console.log(res);
        alert("record added successfully");
        this.formValue.reset();
        this.getAllData();
        
      },
      error=>{alert("something went wrong");
    }
      )
  }
getAllData()
{
  this.api.getEmp().subscribe(res=>{this.empAlldata=res})
  }
  delEmp(data:any){
    this.api.deleteEmp(data.id).subscribe(
      res=>{ alert("record deleted successfully!");
      this.getAllData();
    }
    )
  }
  onEditEmp(data:any){
    this.formValue.controls['name'].setValue(data.name)
    this.formValue.controls['email'].setValue(data.email)
    this.formValue.controls['mobile'].setValue(data.mobile)
    this.formValue.controls['address'].setValue(data.address)
    this.formValue.controls['salary'].setValue(data.salary)
  }
  updateEmpData(){
    this.empobj.name=this.formValue.value.name;
    this.empobj.email=this.formValue.value.email;
    this.empobj.mobile=this.formValue.value.mobile;
    this.empobj.address=this.formValue.value.address;
    this.empobj.salary=this.formValue.value.salary;
    this.api.updateEmp(this.empobj,this.empobj.id).subscribe(
      res=>{ alert("record updated succesfully!")},
      err=>{ alert("something went wrong??");}
    )
  }
}
