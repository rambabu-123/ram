export class EmpData {
    id:number=0;
    name:string='';
    email:string='';
   mobile:string='';
   address:string='';
   salary:number=0;
   }