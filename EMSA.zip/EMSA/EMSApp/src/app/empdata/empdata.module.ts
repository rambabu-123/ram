import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';



@NgModule({
  declarations: [],
  imports: [
    CommonModule
  ]
})
export class EmpdataModule {
  id:number=0;
  name:string='';
  email:string='';
 mobile:string='';
 address:string='';
 salary:number=0;
 }
